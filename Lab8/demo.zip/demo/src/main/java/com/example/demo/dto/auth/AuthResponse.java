package com.example.demo.dto.auth;

import lombok.Data;

@Data
public class AuthResponse {
    private String token;
}
